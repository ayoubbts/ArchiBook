package fr.isep;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.ObjectNode;


/**
 * 
 * @author Ayoub BENTIRES ALJ
 *
 */
public class LdapContent {
	static ResourceBundle bundle = ResourceBundle.getBundle("domaine.properties.config") ; 
    public static final String LDAP_HOSTNAME = bundle.getString("LDAP_HOSTNAME");
    public static final String LDAP_PROTOCOL = bundle.getString("LDAP_PROTOCOL");
    public static final String LDAP_PORT = bundle.getString("LDAP_PORT");
    public static final String LDAP_BASE_DN = bundle.getString("LDAP_BASE_DN");
    public static final String LDAP_CONNECTION_USERNAME = bundle.getString("LDAP_CONNECTION_USERNAME");
    public static final String LDAP_CONNECTION_PASSWORD = bundle.getString("LDAP_CONNECTION_PASSWORD");

    static List returnResult() {
    List list = new ArrayList();
    Hashtable props = new Hashtable();
	props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
	props.put(Context.SECURITY_AUTHENTICATION, "simple");
	props.put(Context.SECURITY_PRINCIPAL, LDAP_CONNECTION_USERNAME);
	props.put(Context.SECURITY_CREDENTIALS, LDAP_CONNECTION_PASSWORD);

	String ldapUrl = LDAP_PROTOCOL + "://" + LDAP_HOSTNAME + ":" + LDAP_PORT + "/";	
	props.put(Context.PROVIDER_URL, ldapUrl);

	String filter = "(objectClass=inetOrgPerson)";
        
        String[] returningAttributes = {"givenName", "sn", "cn", "uid", "userpassword", "mail", "modifytimestamp"};
        
        try{
        DirContext ctx = new InitialDirContext(props);
        SearchControls sctrl = new SearchControls();
        sctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
        sctrl.setReturningAttributes(returningAttributes);
        NamingEnumeration enumeration = ctx.search(LDAP_BASE_DN, filter, sctrl);
        while (enumeration.hasMoreElements()){
            SearchResult sr = (SearchResult) enumeration.next();
            for (String s : returningAttributes){
                if (!s.equalsIgnoreCase("userpassword")){
                    list.add(sr.getAttributes().get(s).get(0).toString());
                } else{
                    list.add(new String((byte[]) sr.getAttributes().get(s).get()));
                }
            }
        }
        
        } catch(Exception ex){
            System.out.println("Something wrong happened: " + ex.getMessage());
        }
		return list;
    }   
    
    static List ldapToJson() {
    	
    	List list = returnResult();
    	System.out.println(""+list);
    	
    	ObjectMapper mapper = new ObjectMapper();
    	int cpt = 1;
		ObjectNode node = null ;
		List users = new ArrayList();
    	
		for(int i=0; i<list.size(); i++) {
			cpt = cpt + 1;
			ObjectNode node$i = mapper.createObjectNode();
			if (cpt == 8) {
		    	node$i  = mapper.createObjectNode();
				node$i.put("givenName",""+list.get(i-6));
				node$i.put("sn" , "" + list.get(i-5)); 
				node$i.put("cn" , "" + list.get(i-4));
				node$i.put("uid" , "" + list.get(i-3));
				node$i.put("user password" , ""+ list.get(i-2));
				node$i.put("mail" , ""+ list.get(i-1));
				node$i.put("School" , "ISEP");
				node$i.put("modifytimestamp" , ""+list.get(i));
				users.add(node$i);
				cpt = 1;
				
			}
    	}    	
		return users;
    }
    
}