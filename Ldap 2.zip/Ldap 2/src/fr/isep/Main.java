package fr.isep;

/**
 * 
 * @author Ayoub BENTIRES ALJ
 *
 */
public class Main {

	public static void main(String[] args) throws Exception {
		HttpURLConnectionExample http = new HttpURLConnectionExample();
		System.out.println("\nTesting 2 - Send Http POST request");
		http.sendPost();
		
	}

}
 