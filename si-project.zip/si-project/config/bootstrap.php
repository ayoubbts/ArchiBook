<?php

define('DEBUG',true);
if(DEBUG)
{
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
}

$dir_class = array('controller','modele');
foreach ($dir_class as $dir) {
	foreach (glob($dir."/*.php") as $filename)
	{
	    include $filename;
	}
}

$config = __DIR__.'/';
include($config.'setting.php');

$session = new Session();
