<?php

    define('DBNAME','c0archibook');
    define('HOST','localhost');
    define('USER','c0archibook');
    define('PASS','hfgbhBNgPWB#3');

    define('BASEURL','http://archibook.webivers.com/');
