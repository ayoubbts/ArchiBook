<?php

    define('DBNAME','ldap');
    define('HOST','localhost');
    define('USER','root');
    define('PASS','root');
    define('BASEURL','http://localhost/si-project/');
