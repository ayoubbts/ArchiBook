<?php
include_once(__DIR__.'/config/bootstrap.php');
$controller = new connexionController();
$action = @$_GET['action'];
if($action=='connexion')
  {
    $controller->connect();
  }
  else{
print $controller->show();
}
