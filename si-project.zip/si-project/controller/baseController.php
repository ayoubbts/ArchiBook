<?php
class baseController{
  public function __construct(){
  }
  public function view($template , $vars = array())
  {
    foreach ($vars as $key => $value) {
      $$key = $value;
    }

    ob_start();
    include(__DIR__."/../vue/".$template.".php");
    $resultat = ob_get_clean();
    ob_flush();
    return $resultat;
  }


}



 ?>
