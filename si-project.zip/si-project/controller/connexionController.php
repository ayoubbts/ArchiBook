<?php
class connexionController extends baseController{
  public function show()
  {

    $title = 'Connexion';
    $vars = array();
    $vars['bannerTitle'] = $this->view('banner_title',['title'=>$title]);
    $contenu = $this->view('connexion',$vars);

    $vars = array();
    $vars['contenu'] = $contenu;
    $vars['title'] = $title;

    return $this->view('gabarit',$vars);
  }

  public function connect()
  {
    global $session;
    $login = $_POST['login'];
    $pass = $_POST['mdp'];

$db = new DB();
$user = $db->getBy('content','Email',$login);
    if($login == $user[0]['Email'] && $this->check_password($pass,$user[0]['Password']))
    {
      $session->setConnected(true);
      $forward = isset($session->forward)?$session->forward:'user.php?action=list';
      unset($session->forward);
      $session->redirectTo($forward);
    }
else
$session->redirectTo('connexion.php');
  }

  function check_password($password, $hash)
 {
 if ($hash == '') // no password
 {
 //echo "No password";
 return FALSE;
 }

 if ($hash{0} != '{') // plaintext password
 {
 if ($password == $hash)
 return TRUE;
 return FALSE;
 }

 if (substr($hash,0,7) == '{crypt}')
 {
 if (crypt($password, substr($hash,7)) == substr($hash,7))
 return TRUE;
 return FALSE;
 }
 elseif (substr($hash,0,5) == '{MD5}')
 {
 $encrypted_password = '{MD5}' . base64_encode(md5( $password,TRUE));
 }
 elseif (substr($hash,0,6) == '{SHA1}')
 {
 $encrypted_password = '{SHA}' . base64_encode(sha1( $password, TRUE ));
 }
 elseif (substr($hash,0,6) == '{SSHA}')
 {
 $salt = substr(base64_decode(substr($hash,6)),20);
 $encrypted_password = '{SSHA}' . base64_encode(sha1( $password.$salt, TRUE ). $salt);
 }
 else
 {
 echo "Unsupported password hash format";
 return FALSE;
 }
echo "$hash";
echo "$encrypted_password";
 if ($hash == $encrypted_password)
 return TRUE;

 return FALSE;
 }

}
?>
