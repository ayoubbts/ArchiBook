<?php
class indexController extends baseController{
  public function show()
  {
    $title = 'Index';
    $vars = array();
    $vars['bannerTitle'] = $this->view('banner_title',['title'=>$title]);
    $contenuindex = $this->view('indexcontent',$vars);

    $vars = array();
    $vars['contenu'] = $contenuindex;
    $vars['title'] = $title;

    return $this->view('gabarit',$vars);
  }
}
 ?>
