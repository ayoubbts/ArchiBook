<?php
class ldapController extends baseController{
  public function sync()
  {
    $inputJSON = ($_POST['json']);
    $users = json_decode($inputJSON, TRUE); //convert JSON into array
    $last_sync = file_get_contents('sync.data');

    foreach ($users as $user){
      if ($last_sync >= $user ['modifytimestamp'] ){
        continue;
      }
       $ouser = new User();
       $ouser->First_Name = $user['givenName'];
       $ouser->Last_Name = $user['sn'];
    	 $ouser->Common_Name = $user['cn'];
    	 $ouser->UserID = $user['uid'];
    	 $ouser->Password = $user['user password'];
    	 $ouser->Email = $user['mail'];
    	 $ouser->School = $user['School'];
       $ouser->save();
    }
    $format = "YmdHis";
	date_default_timezone_set('UTC');
    file_put_contents('sync.data',date ($format));
  }

}
?>
