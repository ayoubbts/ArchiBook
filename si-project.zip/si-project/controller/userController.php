<?php

  class userController extends baseController{
    public function lister()
    {
      //jsondata();
      global $session;

      if(!$session->isConnected() )
      {
        $session->forward = 'user.php?action=list';
        $session->redirectTo('connexion.php');
      }
      $user = new User();
      $user_list = $user->all();

      $title = 'Tous les utilisateurs';

      $vars = array();
      $vars['liste_users'] = $user_list;
      $vars['bannerTitle'] = $this->view('banner_title',['title'=>$title]);
      $listUsers =  $this->view('user_list',$vars);

      $vars = array();
      $vars['contenu'] = $listUsers;
      $vars['title'] = $title;
      return $this->view('gabarit',$vars);

    }

  }
?>
