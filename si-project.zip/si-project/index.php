<?php
include_once(__DIR__.'/config/bootstrap.php');
$controller = new indexController();
print $controller->show();
