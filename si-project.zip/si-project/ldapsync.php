<?php
var_dump($_POST);
include_once(__DIR__.'/config/bootstrap.php');
$controller = new ldapController();
$controller->sync();
