<?php
class DB{

  private $db;

  public function __construct()
  {
    try
    {
      if(isset($this->db))
        return;

      $db = new PDO("mysql:host=".HOST.";dbname=".DBNAME."", USER, PASS);
      $db->query("SET NAMES UTF8");
      $this->db = $db;
    }
    catch (Exception $e)
    {
      die('Erreur: '.$e->getMessage());
    }
  }

  public function __destruct()
  {
      unset($this->db);
  }

  public function query($q)
  {
    var_dump($q);
    try
    {
      return $this->db->query($q);
    }
    catch (Exception $e)
    {
      die('Erreur: '.$e->getMessage());
    }
  }

  public function getResults($q)
  {
    $res = $this->query($q);
    $arr = array();
    while ($line = $res->fetch())
    {
      $arr[] = $line;
    }
    return $arr;
  }

  public function insert($table, $values)
  {
    $q = "replace into $table (";

    $k = '';
    foreach ($values as $key => $value) {
      $k .= addslashes($key).",";
    }
    $k = rtrim($k,',');

    $q .= $k.")values(";

    $v = '';
    foreach ($values as $key => $value) {
      $v .= "'".addslashes($value)."',";
    }
    $v = rtrim($v,',');

    $q .= $v;
    $q .= ")";

    return $this->query($q);
  }

  public function getBy($table,$key,$val)
  {
    $q = "select * from $table where $key = '$val'";
    return $this->getResults($q);
  }
}
