<?php
class Session{
  private $connected;
  public $forward;

  public function __construct()
  {
    session_start();
    $this->connected = isset($_SESSION['connected'])?$_SESSION['connected']:false;
  }

  public function isConnected()
  {
    return $this->connected;
  }

  public function redirectTo($url)
  {
    header('Location: '.$url);
    die;
  }

  public function setConnected($connected = false)
  {
    $this->connected = $connected;
    $_SESSION['connected'] = $connected;
  }
}
 ?>
