<?php
class User extends DB{


    public $First_Name ;
    public $Last_Name ;
  	public $Common_Name ;
  	public $UserID ;
  	public $Password ;
  	public $Email ;
  	public $School ;

  function all()
  {
    return $this->getResults("SELECT * FROM content");
  }

  function save()
  {
    return $this->insert('content',[ 'First_Name' => $this->First_Name,
    'Last_Name' => $this->Last_Name,
  	'Common_Name' => $this->Common_Name,
  	'UserID' => $this->UserID,
  	'Password' => $this->Password,
  	'Email' => $this->Email,
  	'School' => $this->School]);
  }

}


 ?>
