<?php
include_once(__DIR__.'/config/bootstrap.php');
$action = @$_GET['action'];
$controller = new userController();
$resultat = '';
if ($action == 'list') {
  $resultat = $controller->lister();
}
print $resultat;

 ?>
