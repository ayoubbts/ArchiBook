<div id="banniereautre" class="banner2">
  <div class="diamond">
    <div></div>
  </div>
  <h1 class="text"><?= $title ?></h1>
</div>
