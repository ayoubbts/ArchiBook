<?= $bannerTitle ?>

<form method="POST" class="basic-grey connecto" action="connexion.php?action=connexion">
  <div id="banniereco">&#12297;&nbsp;Connectez-vous&nbsp;&#12296;</div>
  <p>

    <input type="text" name="login" placeholder="Identifiant" autofocus required/>
    <p>
      &nbsp;
    </p>
    <p>
      &nbsp;
    </p>
    <input type="password" name="mdp" required placeholder="Mot de passe"/>
  </p>
  <p>
    <input value="se connecter" type="submit"/>
  </p>

<br />

      <p><a href="index.php?page=forget_mdp">Mot de passe oublié ?</a>  </p>


</form>
