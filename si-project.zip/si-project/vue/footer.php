<div id="piedpage">
<footer>
  <ul>
    <a href="index.php?page=mention_legales">Mentions légales</a>&nbsp;&#124;&nbsp;
      <a href="index.php?page=conditions">Conditions d'utilisation</a>&nbsp;&#124;&nbsp;
    <a href="index.php?page=assistance">Contact et assistance</a>
  </ul>
</footer>
</div>

<script defer src="vue/material.min.js"></script>

</body>
</html>
