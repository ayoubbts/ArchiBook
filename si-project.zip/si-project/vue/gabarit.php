<?php  require("header.php");?>

<?= $vars['contenu']; //=>  <?php echo $contenu?>

<?php  require("footer.php");?>
