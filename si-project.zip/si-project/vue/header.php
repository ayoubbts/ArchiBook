<html lang="fr">
  <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

      <!--Ces lignes permettent de rediriger un utilisateur si il desactive le JS-->
      <noscript>
        <meta http-equiv="refresh" content="1;vue/activer_JS.html" />
      </noscript>

      <!--link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"-->
    <link rel="stylesheet" href="vue/material.min.css" />
    <link rel="stylesheet" type="text/css" href="vue/style.css" />
      <title>
          <?= $title;?>
      </title>
  </head>

  <body>
    <div id="blur"></div>
    <?php
    //définition du menu en fonction du mode de connection
    global $session;
    if($session->isConnected())
    {
      include('menu_connecte.php');
    }
    elseif(!$session->isConnected())
    {
      include('menu_deconnecte.php');
    }
    ?>
