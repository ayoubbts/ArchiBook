<?= $bannerTitle ?>
<b>Bienvenue sur Index</b>
