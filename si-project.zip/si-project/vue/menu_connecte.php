<div id=menu>
<ul>
        <li class ="nav"> <a href="user.php?action=list">LISTE</a></li>
        <li class ="nav"> <a href="deconnexion.php">DECONNEXION</a></li>
</ul>
</div>
