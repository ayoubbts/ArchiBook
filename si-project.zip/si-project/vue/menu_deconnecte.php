<div id="menu">

      <ul>
        <li class ="nav"> <a href="index.php"> ACCUEIL </a></li>
        <li class ="nav"> <a href="index.php?page=assistance"> CONTACT </a>
        <li class ="nav"> <a href="connexion.php"> CONNEXION </a> </li>
      </ul>
    </div>
