<body id="bodyautre">
  <div id="contenu">

<?= $bannerTitle ?>

<input value="&#12296; Retour" class="boutonretour" type="submit" onclick="history.go(-1)">

<form class="basic-grey utilisateuro">

   <div class="mdl-cell mdl-cell--6-col-tablet mdl-cell--10-col-desktop mdl-cell--stretch">
   <table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp">
   <h3>Liste des utilisateurs</h3>

   <thead> <!-- En-tête du tableau -->
       <tr>
           <th>Nom</th>
           <th>Prénom</th>
           <th>Surnom</th>
           <th>Id</th>
           <th>Email</th>
           <th></th>
           <th>Ecole</th>
       </tr>
   </thead>

<?php
// Affichage des données capteurs en tableau
foreach ($liste_users as $user) :
?>
   <tbody> <!-- Corps du tableau -->
       <tr>
           <td> <?php echo $user['Last_Name']; ?></td>
           <td> <?php echo $user['First_Name']; ?></td>
           <td> <?php echo $user['Common_Name']; ?></td>
           <td> <?php echo $user['UserID']; ?></td>
           <td> <?php echo $user['Email']; ?></td>
           <td></td>
           <td> <?php echo $user['School']; ?></td>
       </tr>
   <?php
endforeach;
?>

   </tbody>
</table>
</div>
</section>

</div>
</body>
